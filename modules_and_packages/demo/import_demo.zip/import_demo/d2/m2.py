__all__ = ['a']

a = 'm2 var a'
b = 'm2 var b' 
