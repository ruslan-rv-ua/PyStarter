import m1

print('main.py')
print(f'{__file__=}')
print(f'{__name__=}')
