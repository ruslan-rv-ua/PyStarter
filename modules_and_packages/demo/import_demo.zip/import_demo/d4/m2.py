if __name__ == '__main__':
    print('m1.py')
    print(f'{__file__=}')
    print(f'{__name__=}')
