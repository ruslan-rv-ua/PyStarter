print('m1.py')
print(f'{__file__=}')
print(f'{__name__=}')
