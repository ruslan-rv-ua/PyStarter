print('package2 module1')
