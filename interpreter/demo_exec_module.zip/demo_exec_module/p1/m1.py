print('package1 module1')
