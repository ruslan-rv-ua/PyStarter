print()
print('Це імпортується модуль mod1')
print(f'{__file__=}')
print(f'{__name__=}')

if __name__ == '__main__':
    print('модуль mod1 запущено як скрипт')
