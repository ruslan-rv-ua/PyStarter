import mod1

print()
print('Це імпортується модуль main')
print(f'{__file__=}')
print(f'{__name__=}')
