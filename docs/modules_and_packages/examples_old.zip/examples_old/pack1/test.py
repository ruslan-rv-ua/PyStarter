from subfolder import *

module1.hello()
