__all__ = ['convert']

def convert(file, to_format):
	print(f'converting file "{file}" to {to_format}')