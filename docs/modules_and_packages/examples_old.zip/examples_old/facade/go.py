from audioconverter import convert
convert('sound.mp3', 'wave')

from audioconverter import mp3_to_wave
mp3_to_wave(None)

from audioconverter import *
wave_to_mp3(1)