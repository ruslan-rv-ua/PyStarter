﻿# Приклад абсолютного імпорта
from framework import models

class ArticleModel(models.Model):
    """тут тіпа модель статті"""